namespace IBI.FileSystem
{
    partial class DataClasses_LocalDataContext
    {
    }
}