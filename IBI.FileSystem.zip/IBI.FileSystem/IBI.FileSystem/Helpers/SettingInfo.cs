﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBI.FileSystem.Helpers
{
    public static class SettingInfo
    {
        public static string RemoteServer { get; set; }
        public static string RemoteServerPath { get; set; }
        public static string RemoteUsername { get; set; }
        public static string RemotePassword { get; set; }
    }
}
